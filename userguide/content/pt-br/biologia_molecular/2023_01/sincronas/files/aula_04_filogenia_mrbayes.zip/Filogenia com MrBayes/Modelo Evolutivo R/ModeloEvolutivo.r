# Carregar as bibliotecas necessárias
library(phangorn)

######################### Avalição de Modelo Evolutivo #########################

# Importar o alinhamento (pode ser 'DNA', 'AA', 'CODON' ou 'USER') basta definir
# em type
MeuAlinhamento <- read.phyDat(file = "SNF1_WholeProtein.fas",
                              format = "fasta", type = "AA")
# Gerar a tabela de resultados
Modelo <- modelTest(MeuAlinhamento, model = "all")
# Ordenar a tabela em ordem crescente baseado no critério AIC (quarta coluna)
Modelo <- Modelo[order(Modelo["AIC"]),]
# Visualizar o resultado
Modelo
